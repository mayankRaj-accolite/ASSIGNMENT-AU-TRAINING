import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/providers/book.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

  book:any = [];
  
  constructor( private bookService:BookService) { }
  

  ngOnInit() {
    this.bookService.getAllBooks().subscribe((response)=>{
      if(response && response.length>0){
        this.book=response;
        console.log(this.book);
      }
    });
    }

    posttheData(obj){
      console.log(obj);
      this.bookService.addthebook(obj).subscribe((Response)=>{

      });
    }
  
  }



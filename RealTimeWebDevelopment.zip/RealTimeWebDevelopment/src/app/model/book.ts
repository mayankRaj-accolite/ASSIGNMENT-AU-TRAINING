export class Book {

   id: string;
   bookName: string;
   description:string;
   authorName:string;
   price:number;
}


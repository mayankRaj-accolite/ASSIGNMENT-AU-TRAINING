package com.au.library.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.au.library.model.Book;
import com.au.library.model.cart;

@Repository
public class BooksDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<Book> all() {
		return jdbcTemplate.query("select * from book", (rs, i) -> {
			return new Book(rs.getString("id"), rs.getString("title"), rs.getString("author"), rs.getDouble("price"),
					rs.getString("description"));
		});
	}

	public Book getId(String id) {
		return jdbcTemplate.queryForObject("select * from book where id='" + id + "'", (rs, i) -> {
			return new Book(rs.getString("id"), rs.getString("title"), rs.getString("author"), rs.getDouble("price"),
					rs.getString("description"));
		});
	}

	public Book create(Book book) {
		jdbcTemplate.update("insert into book(id, title, author, price , description)"
				+ "values(?,?,?,?,?)",
		new  Object[] 
				{book.getId(), book.getBookName(),book.getAuthorName(),book.getPrice(),book.getDescription() });
		return book;
	}
	
	public Book Addtocart(Book book) {
		jdbcTemplate.update("insert into book1 values(?,?,?);", book.getId(),book.getBookName(),book.getAuthorName());
		return book;
	}
	
	public List<cart> one(){

		return jdbcTemplate.query("select * from cart", (rs, i) -> {
			return new cart(rs.getString("id"), rs.getString("title"), rs.getString("author"));

		});

	}
	public Book createone(Book book) {
		jdbcTemplate.update("insert into cart values(?,?,?);",book.getId(),book.getBookName(),book.getAuthorName());
		return book;
	}
	
	
}

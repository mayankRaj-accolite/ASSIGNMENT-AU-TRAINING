package com.au.library.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.au.library.model.Book;
import com.au.library.model.cart;
import com.au.library.repository.BooksDAO;

@RestController
public class BooksController {
	
	@Autowired
	BooksDAO booksDao;

	@RequestMapping(value="/books",method=RequestMethod.GET, produces="application/json")
	public List<Book> getAll() {
		return booksDao.all();
	}
	
	@RequestMapping(value="/books/{bookId}/get",method=RequestMethod.GET)
	public Book getBookById(@PathVariable(value="bookId") String bookId) {
		
		return booksDao.getId(bookId);
	
	}
	
	@RequestMapping(value="/books",method=RequestMethod.POST)
	public Book insertBook(@RequestBody Book book) 
	{
		return booksDao.create(book);
		
	}
	
//	@RequestMapping(value="/carts",method=RequestMethod.POST)
//	public Book Addtocart(@RequestBody Book book) {
//		
//		return booksDao.Addtocart(book);
//		
//		
//	}
	
//	@RequestMapping(value="/getcart")
//	public List<cart> getthecart() {
//		
//		return booksDao.cartget();
//	}
	
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public Book insertoneBook(@RequestBody Book book) 
	{
		return booksDao.createone(book);
		
	}
	@RequestMapping(value="/getonebook",method=RequestMethod.GET, produces="application/json")
	public List<cart> getoneAll() {
		return booksDao.one();
	}
	
	
}
